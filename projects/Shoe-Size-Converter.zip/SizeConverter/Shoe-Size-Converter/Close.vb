﻿Module close
    Dim newform As SizeConverter
    Sub clse()
        'this closes the program
        SizeConverter.Close()
    End Sub
End Module
