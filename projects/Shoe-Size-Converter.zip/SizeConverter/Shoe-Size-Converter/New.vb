﻿Module new1
    Sub ne()
        'this opens a new form
        Dim oForm As SizeConverter
        oForm = New SizeConverter
        oForm.Show()
        oForm = Nothing
    End Sub
End Module
