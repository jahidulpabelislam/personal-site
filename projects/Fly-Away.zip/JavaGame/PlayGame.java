public class PlayGame
{
     public static void main(String[] args)
     {
          Game g = new Game();
          g.play();
     }
}